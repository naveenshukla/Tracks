package com.app.hackathon.tracks;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

/**
 * Created by Satyam Poddar on 02-Apr-16.
 */
public class ScreenSlideFragment1 extends android.support.v4.app.Fragment{
    public String src, destination;
    EditText srctext,desttext;
    Button bjo;
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.d("hello","frag1");
        ViewGroup rootView = (ViewGroup) inflater.inflate(
                R.layout.page1, container, false);
        srctext = (EditText) rootView.findViewById(R.id.source);
        desttext = (EditText) rootView.findViewById(R.id.destination);
        bjo = (Button)rootView.findViewById(R.id.bjourney);
        bjo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                destination = desttext.getText().toString();
                src = srctext.getText().toString();
                /*String str = null;
                str = src.concat("search%");
                str = str.concat(src);*/
                /* BackgroundTask backgroundTask = new BackgroundTask(this);
                backgroundTask.execute("search","naveen","+9121314245",src,destination);*/
                String str ="search%"+ src.concat("%" + destination);

                Intent i = new Intent(getActivity(),FinalList.class);
                i.putExtra("mytext",str);
                startActivity(i);
            }
        });
        return rootView;

    }

}
