package com.app.hackathon.tracks;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

/**
 * Created by Satyam Poddar on 02-Apr-16.
 */
public class ScreenSlideFragment3 extends android.support.v4.app.Fragment {
    EditText et3;
    String s3;
    Button bjo1;
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(
                R.layout.page3, container, false);
        et3 = (EditText) rootView.findViewById(R.id.gameandsport);

        bjo1 = (Button)rootView.findViewById(R.id.bgames);
        bjo1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                s3 = et3.getText().toString();
                /*String str = null;
                str = src.concat("search%");
                str = str.concat(src);*/
                /* BackgroundTask backgroundTask = new BackgroundTask(this);
                backgroundTask.execute("search","naveen","+9121314245",src,destination);*/
                String str ="game%"+s3+"%whocares";

                Intent i = new Intent(getActivity(),FinalList.class);
                i.putExtra("mytext",str);
                startActivity(i);
            }
        });
        return rootView;
    }
}
