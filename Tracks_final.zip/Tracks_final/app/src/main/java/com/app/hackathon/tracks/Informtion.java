package com.app.hackathon.tracks;

/**
 * Created by Satyam Poddar on 03-Apr-16.
 */
public class Informtion {
    public int itemId;
    String Title;
}
