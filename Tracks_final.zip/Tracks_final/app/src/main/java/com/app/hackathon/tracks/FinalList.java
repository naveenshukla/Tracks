package com.app.hackathon.tracks;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.BounceInterpolator;
import android.widget.ListAdapter;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ExecutionException;

/**
 * Created by Satyam Poddar on 30-Jan-16.
 */
public class FinalList extends AppCompatActivity{
    String src,dest;
    private Toolbar toolbar;
    private SwipeMenuListView mList;
    String[] events_1;
    int[] images;
    String[] timing;
    String[] intents;
    TextView eventName;
    public ArrayList<String> name = new ArrayList<String>();
    public ArrayList<String> phone = new ArrayList<String>();
    public ArrayList<String> src1 = new ArrayList<String>();
    public ArrayList<String> dest1 = new ArrayList<String>();
    public ArrayList<String> gamename = new ArrayList<String>();
    //public Boolean[] check = new ArrayList<Boolean>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        Log.d("hello", "finallist");

        toolbar = (Toolbar) findViewById(R.id.app_bar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mList = (SwipeMenuListView) findViewById(R.id.listView);
        SwipeMenuCreator creator = new SwipeMenuCreator() {

            @Override
            public void create(SwipeMenu menu) {
                // create "delete" item
                SwipeMenuItem deleteItem = new SwipeMenuItem(
                        getApplicationContext());
                // set item background
                deleteItem.setBackground(new ColorDrawable(Color.rgb(0xfb,
                        0xc0, 0x2d)));
                // set item width
                deleteItem.setWidth(dp2px(90));
                // set a icon
                deleteItem.setIcon(R.drawable.isms);
                // add to menu
                menu.addMenuItem(deleteItem);
            }
        };
        // set creator
        mList.setMenuCreator(creator);
        mList.setOpenInterpolator(new BounceInterpolator());
        mList.setCloseInterpolator(new BounceInterpolator());
        //Bundle bundle = getIntent().getExtras();
        //String message  =bundle.getString("message");
        //String[] msg = message.split("%");
        SharedPreferences sharedPreferences = getSharedPreferences("sharedPreferences", Context.MODE_APPEND);
        String[] msg = getIntent().getStringExtra("mytext").split("%");
        Log.d("hello",msg[0]);
        Log.d("hello",msg[1]);
        Log.d("hello",msg[2]);
        //Log.d("hello", sharedPreferences.getString("Name", null));
        //backgroundTask.execute("search", sharedPreferences.getString("Name", null), sharedPreferences.getString("Number", null), msg[0], msg[1]);
       if(msg[0].equals("search")){
           Log.d("hello","searching");
           BackgroundTask backgroundTask = new BackgroundTask(this);
           String result = null;
           try {
               result = backgroundTask.execute("search", sharedPreferences.getString("Name", null), sharedPreferences.getString("Number", null), msg[1], msg[2]).get();
               Log.d("hello","rajat gandu" + " " + result);
           } catch (InterruptedException e) {
               e.printStackTrace();
           } catch (ExecutionException e) {
               e.printStackTrace();
           }
           try {
               JSONObject mainObject = new JSONObject(result);
               // Log.d("hello",result);
               JSONArray cast = mainObject.getJSONArray("Orders");
               for (int i = 0; i < cast.length(); i++) {
                   JSONArray user = cast.getJSONArray(i);
                   name.add((String) user.get(1));
                   phone.add((String)user.get(0));
                   src1.add((String)user.get(2));
                   dest1.add((String) user.get(3));
               }
           } catch (JSONException e) {
               //Toast.makeText(ctx,"no one is going ",Toast.LENGTH_LONG).show();
               e.printStackTrace();
           }
       }
        if(msg[0].equals("food")){
            Log.d("hello","eating");
            BackgroundTask backgroundTask = new BackgroundTask(this);
            String result = null;
            try {
                result = backgroundTask.execute("food", sharedPreferences.getString("Name", null), sharedPreferences.getString("Number", null), msg[1], msg[2]).get();
                //Log.d("hello","rajat gandu" + " " + result);
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
            try {
                JSONObject mainObject = new JSONObject(result);
                // Log.d("hello",result);
                JSONArray cast = mainObject.getJSONArray("Orders");
                for (int i = 0; i < cast.length(); i++) {
                    JSONArray user = cast.getJSONArray(i);
                    name.add((String) user.get(1));
                    phone.add((String)user.get(0));
                    src1.add((String)user.get(2));
                    dest1.add((String) user.get(3));
                }
            } catch (JSONException e) {
                //Toast.makeText(ctx,"no one is going ",Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        }
        if(msg[0].equals("study")){
            Log.d("hello","studying i am maggu rajat gaandu");
            BackgroundTask backgroundTask = new BackgroundTask(this);
            String result = null;
            try {
                result = backgroundTask.execute("study", sharedPreferences.getString("Name", null), sharedPreferences.getString("Number", null), msg[1], msg[2]).get();
                //Log.d("hello","rajat gandu" + " " + result);
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
            try {
                JSONObject mainObject = new JSONObject(result);
                // Log.d("hello",result);
                JSONArray cast = mainObject.getJSONArray("Orders");
                for (int i = 0; i < cast.length(); i++) {
                    JSONArray user = cast.getJSONArray(i);
                    name.add((String) user.get(1));
                    phone.add((String)user.get(0));
                    src1.add((String)user.get(2));
                    dest1.add((String) user.get(3));
                }
            } catch (JSONException e) {
                //Toast.makeText(ctx,"no one is going ",Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        }
        if(msg[0].equals("game")){

            BackgroundTask backgroundTask = new BackgroundTask(this);
            String result = null;
            try {
                result = backgroundTask.execute("game", sharedPreferences.getString("Name", null), sharedPreferences.getString("Number", null), msg[1],null).get();
                //Log.d("hello","rajat gandu" + " " + result);
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
            try {
                JSONObject mainObject = new JSONObject(result);
                // Log.d("hello",result);
                JSONArray cast = mainObject.getJSONArray("Orders");
                for (int i = 0; i < cast.length(); i++) {
                    JSONArray user = cast.getJSONArray(i);
                    name.add((String) user.get(1));
                    phone.add((String)user.get(0));
                    gamename.add((String)user.get(2));
                }
            } catch (JSONException e) {
                //Toast.makeText(ctx,"no one is going ",Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        }

        //events_1 = new String[] {"Director's Cut", "Double Trouble", "Innovation", "Bindaas Bol", "Tongues on fire","Kahaani"};

        images = new int[] {R.mipmap.ic_launcher,R.mipmap.ic_launcher,R.mipmap.ic_launcher,R.mipmap.ic_launcher,R.mipmap.ic_launcher,R.mipmap.ic_launcher,R.mipmap.ic_launcher,R.mipmap.ic_launcher,R.mipmap.ic_launcher,R.mipmap.ic_launcher,R.mipmap.ic_launcher,R.mipmap.ic_launcher };

        //timing = new String[] {"All day","Sat, 15:00","Fri, 22:00","Fri, 13:00","Sat, 15:00","All day"};

        intents = new String[]{"DES", "DES", "DES", "DES", "DES", "DES", "DES", "DES", "DES", "DES", "DES","DES", "DES", "DES", "DES", "DES", "DES", "DES", "DES", "DES", "DES", "DES" };
       /* check = new Boolean[]{false,false,false,false,false,false,false,false,false,false,false,false,false,false
                ,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false};*/
        initList(name, images, phone, intents);
        Log.d("hello", "uptothis3");

    }



    public void initList(ArrayList<String> eventsArray, int[] imagesList, ArrayList<String> timingList, String[] intentsList) {
       Log.d("hello",String.valueOf(eventsArray.size()));
        if(eventsArray.size() != 0) {

            ArrayList<HashMap<String, String>> eventList = new ArrayList<HashMap<String, String>>();

            for(int i = 0; i < eventsArray.size(); i++) {
                HashMap<String, String> candy = new HashMap<String, String>();
                candy.put("event", String.valueOf(eventsArray.get(i)));
                candy.put("image", Integer.toString(imagesList[i]));
                candy.put("time", String.valueOf(timingList.get(i)));
                candy.put("intent", "com.app.hackathon.tracks." + intentsList[i].trim());
                //if(chk[i].ischecked())
                eventList.add(candy);
            }

            ListAdapter adapter = new SimpleAdapter(
                    FinalList.this ,
                    eventList,
                    R.layout.content_list,
                    new String[] { "event", "image", "time", "intent"},
                    new int[] { R.id.event_name, R.id.eventImg, R.id.eventTime, R.id.intent}) {
                @Override
                public View getView(int position, View convertView, ViewGroup parent) {
                    View view = super.getView(position, convertView, parent);
                    TextView item_name = (TextView)view.findViewById(R.id.event_name);

                    return view;
                }
            };

            mList.setAdapter(adapter);
        }
        mList.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(int position, SwipeMenu menu, int index) {
                switch (index) {
                    case 0:

                        String nm = phone.get(position).toString();
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("sms:"
                                + "+91" + nm)));
                        break;
                }
                return false;
            }
        });
    }


    private int dp2px(int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp,
                getResources().getDisplayMetrics());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
}
