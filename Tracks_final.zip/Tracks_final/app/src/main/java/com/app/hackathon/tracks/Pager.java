package com.app.hackathon.tracks;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

/**
 * Created by Satyam Poddar on 02-Apr-16.
 */
public class Pager extends AppCompatActivity{
    private static final int NUM_PAGES = 4;
    Toolbar toolbar;
    TextView act_name;

    private ViewPager mPager;

    /**
     * The pager adapter, which provides the pages to the view pager widget.
     */
    private PagerAdapter mPagerAdapter;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pager);
        Log.d("hello", "Pager");
        // Instantiate a ViewPager and a PagerAdapter.
        toolbar = (Toolbar) findViewById(R.id.titlebar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        act_name = (TextView)findViewById(R.id.activity_name);
        mPager = (ViewPager) findViewById(R.id.pager);
        mPagerAdapter = new ScreenSlidePagerAdapter(getSupportFragmentManager());
        mPager.setAdapter(mPagerAdapter);
        mPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_AboutApp) {
            AlertDialog.Builder builder =
                    new AlertDialog.Builder(this, R.style.AppCompatAlertDialogStyle);
            LayoutInflater inflater = LayoutInflater.from(this);
            View view = inflater.inflate(R.layout.rules, null);

            TextView matter = (TextView) view.findViewById(R.id.matter);
            matter.setText(getString(R.string.aboutapp));

            builder.setView(view);

            builder.setPositiveButton("CLOSE", null);

            builder.show();
            return true;
        }
        else if (id == R.id.action_Aboutus) {
            AlertDialog.Builder builder =
                    new AlertDialog.Builder(this, R.style.AppCompatAlertDialogStyle);
            LayoutInflater inflater = LayoutInflater.from(this);
            View view = inflater.inflate(R.layout.rules, null);

            TextView matter = (TextView) view.findViewById(R.id.matter);
            matter.setText(getString(R.string.aboutus));

            builder.setView(view);

            builder.setPositiveButton("CLOSE", null);

            builder.show();
            return true;
        }
        else if (id == R.id.action_Logout){
            SharedPreferences sharedPreferences = getSharedPreferences("sharedPreferences", Context.MODE_PRIVATE);
            SharedPreferences.Editor e = sharedPreferences.edit();
            //Log.d("hello", s1);
            e.putString("Name", null);
            e.putString("Number", null);
            e.commit();
            Intent intent = new Intent(Pager.this,MainActivity.class);
            startActivity(intent);
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }






    private class ScreenSlidePagerAdapter extends FragmentStatePagerAdapter {
        public ScreenSlidePagerAdapter(FragmentManager fm) {
            super(fm);
        }
        @Override
        public Fragment getItem(int position) {
            switch (position){
                case 0 : return new ScreenSlideFragment1();
                case 1:  return new ScreenSlideFragment2();
                case 2: return new ScreenSlideFragment3();
                case 3: return new  ScreenSlideFragment4();
                default : return null;
            }
        }

        @Override
        public int getCount() {
            return NUM_PAGES;
        }
    }


}
